# Guide_Mode

This is a project for calculating TM guided mode in waveguide.